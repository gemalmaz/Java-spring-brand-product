package com.kodlama.productManager.entities.abstarcts;

public interface Entity {

}
